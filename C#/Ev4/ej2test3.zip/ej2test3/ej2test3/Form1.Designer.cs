﻿namespace ej2test3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbNivelPrioridad = new ComboBox();
            txtDescripcion = new TextBox();
            lstTareas = new ListBox();
            btnAgregarTarea = new Button();
            btnMarcarComoCompletada = new Button();
            btnEliminarSec = new Button();
            btnVaciarList = new Button();
            rbtnCompletadas = new RadioButton();
            rbtnPendientes = new RadioButton();
            lblCont = new Label();
            SuspendLayout();
            // 
            // cmbNivelPrioridad
            // 
            cmbNivelPrioridad.FormattingEnabled = true;
            cmbNivelPrioridad.Location = new Point(274, 11);
            cmbNivelPrioridad.Name = "cmbNivelPrioridad";
            cmbNivelPrioridad.Size = new Size(151, 28);
            cmbNivelPrioridad.TabIndex = 0;
            cmbNivelPrioridad.SelectedIndexChanged += cmbNivelPrioridad_SelectedIndexChanged;
            // 
            // txtDescripcion
            // 
            txtDescripcion.Location = new Point(28, 12);
            txtDescripcion.Name = "txtDescripcion";
            txtDescripcion.Size = new Size(220, 27);
            txtDescripcion.TabIndex = 1;
            txtDescripcion.TextChanged += txtDescripcion_TextChanged;
            // 
            // lstTareas
            // 
            lstTareas.FormattingEnabled = true;
            lstTareas.Location = new Point(557, 94);
            lstTareas.Name = "lstTareas";
            lstTareas.Size = new Size(242, 104);
            lstTareas.TabIndex = 2;
            lstTareas.SelectedIndexChanged += lstTareas_SelectedIndexChanged;
            // 
            // btnAgregarTarea
            // 
            btnAgregarTarea.Location = new Point(12, 59);
            btnAgregarTarea.Name = "btnAgregarTarea";
            btnAgregarTarea.Size = new Size(141, 29);
            btnAgregarTarea.TabIndex = 3;
            btnAgregarTarea.Text = "Agregar tarea";
            btnAgregarTarea.UseVisualStyleBackColor = true;
            btnAgregarTarea.Click += btnAgregarTarea_Click;
            // 
            // btnMarcarComoCompletada
            // 
            btnMarcarComoCompletada.Location = new Point(583, 229);
            btnMarcarComoCompletada.Name = "btnMarcarComoCompletada";
            btnMarcarComoCompletada.Size = new Size(216, 29);
            btnMarcarComoCompletada.TabIndex = 4;
            btnMarcarComoCompletada.Text = "Marcar como completada";
            btnMarcarComoCompletada.UseVisualStyleBackColor = true;
            btnMarcarComoCompletada.Click += btnMarcarComoCompletada_Click;
            // 
            // btnEliminarSec
            // 
            btnEliminarSec.Location = new Point(583, 263);
            btnEliminarSec.Name = "btnEliminarSec";
            btnEliminarSec.Size = new Size(94, 29);
            btnEliminarSec.TabIndex = 5;
            btnEliminarSec.Text = "Eliminar";
            btnEliminarSec.UseVisualStyleBackColor = true;
            btnEliminarSec.Click += btnEliminarSec_Click;
            // 
            // btnVaciarList
            // 
            btnVaciarList.Location = new Point(705, 263);
            btnVaciarList.Name = "btnVaciarList";
            btnVaciarList.Size = new Size(94, 29);
            btnVaciarList.TabIndex = 6;
            btnVaciarList.Text = "Vaciar Lista";
            btnVaciarList.UseVisualStyleBackColor = true;
            btnVaciarList.Click += btnVaciarList_Click;
            // 
            // rbtnCompletadas
            // 
            rbtnCompletadas.AutoSize = true;
            rbtnCompletadas.Location = new Point(643, 64);
            rbtnCompletadas.Name = "rbtnCompletadas";
            rbtnCompletadas.Size = new Size(118, 24);
            rbtnCompletadas.TabIndex = 7;
            rbtnCompletadas.TabStop = true;
            rbtnCompletadas.Text = "Completadas";
            rbtnCompletadas.UseVisualStyleBackColor = true;
            rbtnCompletadas.CheckedChanged += rbtnCompletadas_CheckedChanged;
            // 
            // rbtnPendientes
            // 
            rbtnPendientes.AutoSize = true;
            rbtnPendientes.Location = new Point(643, 34);
            rbtnPendientes.Name = "rbtnPendientes";
            rbtnPendientes.Size = new Size(101, 24);
            rbtnPendientes.TabIndex = 8;
            rbtnPendientes.TabStop = true;
            rbtnPendientes.Text = "Pendientes";
            rbtnPendientes.UseVisualStyleBackColor = true;
            rbtnPendientes.CheckedChanged += rbtnPendientes_CheckedChanged;
            // 
            // lblCont
            // 
            lblCont.AutoSize = true;
            lblCont.Location = new Point(711, 206);
            lblCont.Name = "lblCont";
            lblCont.Size = new Size(71, 20);
            lblCont.TabIndex = 9;
            lblCont.Text = "Contador";
            lblCont.Click += lblCont_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblCont);
            Controls.Add(rbtnPendientes);
            Controls.Add(rbtnCompletadas);
            Controls.Add(btnVaciarList);
            Controls.Add(btnEliminarSec);
            Controls.Add(btnMarcarComoCompletada);
            Controls.Add(btnAgregarTarea);
            Controls.Add(lstTareas);
            Controls.Add(txtDescripcion);
            Controls.Add(cmbNivelPrioridad);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cmbNivelPrioridad;
        private TextBox txtDescripcion;
        private ListBox lstTareas;
        private Button btnAgregarTarea;
        private Button btnMarcarComoCompletada;
        private Button btnEliminarSec;
        private Button btnVaciarList;
        private RadioButton rbtnCompletadas;
        private RadioButton rbtnPendientes;
        private Label lblCont;
    }
}
