namespace ej2test3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            cmbNivelPrioridad.Items.AddRange("Alta","Media","Baja");
            List<string> tareas = new List<string>();
        }

        private void txtDescripcion_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAgregarTarea_Click(object sender, EventArgs e)
        {
            string prioridad;
            prioridad = cmbNivelPrioridad.Text;
            string descripcion;
            descripcion = txtDescripcion.Text;
            if (txtDescripcion.Text=="")
            {
                MessageBox.Show("La descripcion de la tarea esta vacia");
            }
            else
            {
                lstTareas.Items.AddRange($"{descripcion}-{prioridad}");
                int cont = 0;
                lblCont.Text = $"{cont + 1}";
            }
            
            
        }

        private void cmbNivelPrioridad_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void rbtnPendientes_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void rbtnCompletadas_CheckedChanged(object sender, EventArgs e)
        {


        }

        private void lstTareas_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lblCont_Click(object sender, EventArgs e)
        {
            
        }

        private void btnMarcarComoCompletada_Click(object sender, EventArgs e)
        {
            int inde = lstTareas.SelectedIndex;
            lstTareas.Items[inde] = "-✅" + lstTareas.Items[inde];
        }

        private void btnEliminarSec_Click(object sender, EventArgs e)
        {
            int inde = lstTareas.SelectedIndex;
            
            lstTareas.Items.RemoveAt(inde);
        }

        private void btnVaciarList_Click(object sender, EventArgs e)
        {
            lstTareas.Items.Clear();
        }
    }
}
